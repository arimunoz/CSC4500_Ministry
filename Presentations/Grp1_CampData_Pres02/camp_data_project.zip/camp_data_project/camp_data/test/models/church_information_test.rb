require 'test_helper'

class ChurchInformationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
