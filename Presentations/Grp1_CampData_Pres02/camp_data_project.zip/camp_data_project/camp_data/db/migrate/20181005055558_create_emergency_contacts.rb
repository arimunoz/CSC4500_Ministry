class CreateEmergencyContacts < ActiveRecord::Migration[5.2]
  def change
    create_table :emergency_contacts do |t|
      t.string :firstName
      t.string :lastName
      t.integer :phone
      t.string :relationship
      t.integer :personal_information_id

      t.timestamps
    end
  end
end
