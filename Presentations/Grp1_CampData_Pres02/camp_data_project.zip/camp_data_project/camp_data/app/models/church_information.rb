class ChurchInformation < ApplicationRecord
end
