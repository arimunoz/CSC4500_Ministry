Rails.application.routes.draw do
  get 'pages/home'
  get 'pages/about'
  resources :users
  resources :church_informations
  resources :emergency_contacts
  resources :personal_informations
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
