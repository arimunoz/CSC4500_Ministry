class PersonalInformation < ApplicationRecord
end
