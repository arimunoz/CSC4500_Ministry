require 'test_helper'

class PersonalInformationsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @personal_information = personal_informations(:one)
  end

  test "should get index" do
    get personal_informations_url
    assert_response :success
  end

  test "should get new" do
    get new_personal_information_url
    assert_response :success
  end

  test "should create personal_information" do
    assert_difference('PersonalInformation.count') do
      post personal_informations_url, params: { personal_information: { city: @personal_information.city, dob: @personal_information.dob, email: @personal_information.email, firstName: @personal_information.firstName, lastName: @personal_information.lastName, phone: @personal_information.phone, state: @personal_information.state, zip: @personal_information.zip } }
    end

    assert_redirected_to personal_information_url(PersonalInformation.last)
  end

  test "should show personal_information" do
    get personal_information_url(@personal_information)
    assert_response :success
  end

  test "should get edit" do
    get edit_personal_information_url(@personal_information)
    assert_response :success
  end

  test "should update personal_information" do
    patch personal_information_url(@personal_information), params: { personal_information: { city: @personal_information.city, dob: @personal_information.dob, email: @personal_information.email, firstName: @personal_information.firstName, lastName: @personal_information.lastName, phone: @personal_information.phone, state: @personal_information.state, zip: @personal_information.zip } }
    assert_redirected_to personal_information_url(@personal_information)
  end

  test "should destroy personal_information" do
    assert_difference('PersonalInformation.count', -1) do
      delete personal_information_url(@personal_information)
    end

    assert_redirected_to personal_informations_url
  end
end
