class CreatePersonalInformations < ActiveRecord::Migration[5.2]
  def change
    create_table :personal_informations do |t|
      t.string :firstName
      t.string :lastName
      t.integer :phone
      t.string :email
      t.string :city
      t.string :state
      t.integer :zip
      t.date :dob

      t.timestamps
    end
  end
end
