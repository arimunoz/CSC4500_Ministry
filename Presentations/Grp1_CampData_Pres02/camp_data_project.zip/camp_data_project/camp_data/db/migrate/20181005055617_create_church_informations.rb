class CreateChurchInformations < ActiveRecord::Migration[5.2]
  def change
    create_table :church_informations do |t|
      t.integer :personal_information_id
      t.string :home_church
      t.integer :phone

      t.timestamps
    end
  end
end
