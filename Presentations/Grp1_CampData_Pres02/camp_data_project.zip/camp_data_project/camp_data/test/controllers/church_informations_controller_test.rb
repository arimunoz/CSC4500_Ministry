require 'test_helper'

class ChurchInformationsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @church_information = church_informations(:one)
  end

  test "should get index" do
    get church_informations_url
    assert_response :success
  end

  test "should get new" do
    get new_church_information_url
    assert_response :success
  end

  test "should create church_information" do
    assert_difference('ChurchInformation.count') do
      post church_informations_url, params: { church_information: { home_church: @church_information.home_church, personal_information_id: @church_information.personal_information_id, phone: @church_information.phone } }
    end

    assert_redirected_to church_information_url(ChurchInformation.last)
  end

  test "should show church_information" do
    get church_information_url(@church_information)
    assert_response :success
  end

  test "should get edit" do
    get edit_church_information_url(@church_information)
    assert_response :success
  end

  test "should update church_information" do
    patch church_information_url(@church_information), params: { church_information: { home_church: @church_information.home_church, personal_information_id: @church_information.personal_information_id, phone: @church_information.phone } }
    assert_redirected_to church_information_url(@church_information)
  end

  test "should destroy church_information" do
    assert_difference('ChurchInformation.count', -1) do
      delete church_information_url(@church_information)
    end

    assert_redirected_to church_informations_url
  end
end
