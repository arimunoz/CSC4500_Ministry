require "application_system_test_case"

class PersonalInformationsTest < ApplicationSystemTestCase
  setup do
    @personal_information = personal_informations(:one)
  end

  test "visiting the index" do
    visit personal_informations_url
    assert_selector "h1", text: "Personal Informations"
  end

  test "creating a Personal information" do
    visit personal_informations_url
    click_on "New Personal Information"

    fill_in "City", with: @personal_information.city
    fill_in "Dob", with: @personal_information.dob
    fill_in "Email", with: @personal_information.email
    fill_in "Firstname", with: @personal_information.firstName
    fill_in "Lastname", with: @personal_information.lastName
    fill_in "Phone", with: @personal_information.phone
    fill_in "State", with: @personal_information.state
    fill_in "Zip", with: @personal_information.zip
    click_on "Create Personal information"

    assert_text "Personal information was successfully created"
    click_on "Back"
  end

  test "updating a Personal information" do
    visit personal_informations_url
    click_on "Edit", match: :first

    fill_in "City", with: @personal_information.city
    fill_in "Dob", with: @personal_information.dob
    fill_in "Email", with: @personal_information.email
    fill_in "Firstname", with: @personal_information.firstName
    fill_in "Lastname", with: @personal_information.lastName
    fill_in "Phone", with: @personal_information.phone
    fill_in "State", with: @personal_information.state
    fill_in "Zip", with: @personal_information.zip
    click_on "Update Personal information"

    assert_text "Personal information was successfully updated"
    click_on "Back"
  end

  test "destroying a Personal information" do
    visit personal_informations_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Personal information was successfully destroyed"
  end
end
