require 'test_helper'

class PersonalInformationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
