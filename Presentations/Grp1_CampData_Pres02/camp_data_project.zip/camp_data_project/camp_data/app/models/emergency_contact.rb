class EmergencyContact < ApplicationRecord
end
